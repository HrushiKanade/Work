### skeletons folder

This folder contains the template which will be extended by the assembly script
