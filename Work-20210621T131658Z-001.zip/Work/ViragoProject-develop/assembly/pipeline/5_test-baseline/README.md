# Test-Baseline Stage Setup

`File: assembly/pipeline/3_test-baseline/README.md`

Setup the test-baseline stage which will .... cleanup ???


* --> should be authored from Gabor as he did the stage

