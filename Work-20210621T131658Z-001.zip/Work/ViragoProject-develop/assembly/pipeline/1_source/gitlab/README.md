# gitlab
things we need to know about the repository

## request-body.json
a snapshot of a webhook-trigger from gitlab to aws


