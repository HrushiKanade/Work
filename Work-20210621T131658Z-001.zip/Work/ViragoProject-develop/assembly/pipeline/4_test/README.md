# Test Stage Setup

`File: assembly/pipeline/4_test/README.md`

Setup the test stage which will do functional tests whether the baseline rules are in effect as designed.

## Actions Overview

Test stage has four actions:
1. build source from `test` and deploy source into test account
2. run the tests
3. cleanup

## build action
tbd

Info:
* https://docs.aws.amazon.com/codebuild/latest/userguide/how-to-create-pipeline.html

## run tests action
tbd

## cleanup action
tbd