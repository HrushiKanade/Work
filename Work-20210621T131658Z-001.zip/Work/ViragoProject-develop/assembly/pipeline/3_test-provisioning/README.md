# Test-Provisioning Stage Setup

`File: assembly/pipeline/3_test-provisioning/README.md`


Setup the test-provisioning stage which will deploy the source artifact (which is the deployment of the baseline rules and contents onto the test account)

* --> should be authored from Gabor as he did the stage

