





Deployment of new version

check out --> zip --> deploy

packaging ... lambda / stepfunction /

test ... invoke again

test within account

ABC naming function ---> ABC Environment

end of deploy.provion: step function has succeded

develop in different account

clean-up

Environment setup
step 1: by hand
step 2: automatically
paramatrizable
