# Test-Provisioning Stage Artifacts 

`File: assembly/test-provisioning/README.md`

'Run' the new product revision such that it is testable.

TODO:
To be documented by Gabor
