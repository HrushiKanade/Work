# Prod Stage Artifacts 

`File: assembly/prod/README.md`

Deploy the new revision of the product into production.

TODO:
To be documented by gabor
