# Test-baseline Stage Artifacts 

`File: assembly/test-baseline/README.md`

Cleanup the test account.

TODO:
To be documented by gabor
