# Test Stage Artifacts  - Action Cleanup

`not yet implemented`

## Objective
* Cleanup artifacts and resources deployed in the build stage
* deliver output artifacts (like test results)

