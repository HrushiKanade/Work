# Virago repository

## Subject
Virago is a product which creates AWS accounts with 'baselined' policies. 

## Directory structure
### assembly
contains code to assemble the product via CI/CD

### src
The src-directory is the product code. It contains all of the necessary items to recreate the provison process

### test
contains QA-code to accompany the assembling process and test the product
