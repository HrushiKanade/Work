# Documentation

`File: doc/README.md`

High level design documents which need to be under collaborative version control.