## 2.0.2 (3 January 2018)
### Fix
- Fixed Issue with KMS Policy

## 2.0.1 (7 December 2017)
### Improvements
- Added support to override default naming convention for KMS keys as per standard.

## 2.0.0 (6 December 2017)
### Major Release
- Included support to provision and manage KMS Keys.

## 1.0.3 (22 September 2017)
### Improvements
- Support to attach IAM policy to a existing user.

## 1.0.2 (30 August 2017)
### Improvements
- Support to attach managed iam policy attachment for iam user

## 1.0.1 (10 August 2017)
### Improvements
- Assume policy will now be recieved as file stream from module.

## 1.0.0 (8 August 2017)
- Initial release
