# IAM Module:

## Git Project: git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-iam.git

## Description:

```
This Module is used to provision IAM resources:
  •	Module supports creation of IAM Users
  •	Module supports creation of IAM roles and policies.
  •	Module supports attaching existing policies to a role.
  •	Module supports uploading IAM server certificates.
  •	Module supports creation and management of KMS keys.  
```

## Input Variables:

| Variable Name             | Required | Description                                                                                               |
|---------------------------|----------|-----------------------------------------------------------------------------------------------------------|
| iam_instance_profile_name | Optional | Required only if IAM instance profile should be created                                                   |
| iam_role_name             | Optional | Required if new IAM role should be created                                                                |
| iam_existing_role         | Optional | Required if policy should be attached to a existing IAM Role.                                             |
| assume_policy             | Optional | Required if a new IAM role is created. This is to create the assume role policy.                          |
| force_detach_policies     | Optional | Default is false. Use this variable only if force_detach_policies attribute should be enabled.            |
| description               | Optional | Required only if new IAM role is created.                                                                 |
| iam_policy                | Optional | Used to create a new policy.                                                                              |
| iam_policy_name           | Optional | Name of the IAM policy                                                                                    |
| policy_arn                | Optional | Required only if a existing policy is available and it should be attached role.                           |
| iam_user_name             | Optional | Required for creating IAM Users                                                                           |
| iam_user_path             | Optional | Defaults to “/”                                                                                           |
| existing_iam_user_name    | Optional | Required to attach a policy to an existing user.                                                          |
| iam_user_policy_name      | Optional | Provide an name for iam user policy                                                                       |
| iam_user_policy           | Optional | IAM user policy                                                                                           |
| iam_user_policy_arn       | Optional | Required only if exitsing policy ARN should be attached to a IAM User                                     |
| cert_body                 | Optional | Required for certificate to IAM to use with ELB or other services.                                        |
| cert_name                 | Optional | Name of IAM certificate                                                                                   |
| private_key               | Optional | Private key of the certificate                                                                            |
| kms_key_alias_name        | Optional | Required only when overriding default KMS alias naming convention.                                        |
| kms_key_description       | Optional | Required only if KMS key should be created.                                                               |
| key_usage                 | Optional | Defaults to ENCRYPT_DECRYPT                                                                               |
| kms_administrators        | Optional | Required if the KMS key should be managed by specific set of administrators in addition to the root user. |
| deletion_window_in_days   | Optional | Deletion window in days. default is 30 days. should be between 7 and 30                                   |
| is_enabled                | Optional | Default to true. Accepted value is "true or false"                                                        |
| enable_key_rotation       | Optional | Should we enable key rotation. default is false. Accepted value is "true or false"                        |
| vpc_contact               | Optional | Required only for KMS keys resource                                                                       |
| global_costcode           | Optional | Required only for KMS keys resource                                                                       |
| global_orchestration      | Optional | Default is “terraform”.                                                                                   |
| global_department         | Optional | Default is “tio”.                                                                                         |
| global_subdepartment      | Optional | Default is “euc”                                                                                          |
| global_country            | Optional | Default is “gb”                                                                                           |
| cloud_environment         | Optional | Default is “aws”                                                                                          |
| repo_url                  | Optional | Default is "git@gitlab.et-scm.com:tio-euc/euc-terraformcontrol-enterprise.git"                            |
| euc_tower                 | Optional | Default is “enterprise”                                                                                   |
| environment               | Optional | Required only for KMS keys resource                                                                       |

## Usage:

### To create IAM Role:
```
module "iam" {
  source = "git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-iam.git"
  iam_role_name = "${element(split(",", var.iam_role_name), 0)}"
  assume_policy = "${file("${var.assume_policy}")}"
  iam_policy_name   = "${element(split(",", var.iam_policy_name), 0)}"
  iam_policy        = "${file("${var.iam_policy}")}"
}
```

### To create IAM User:
```
module "iam_user" {
  source = "git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-iam.git"
  iam_user_name = "${var.iam_user_name}"
  iam_user_policy_name = "${var.iam_policy_name}"
  iam_user_policy = "${file("${var.iam_user_policy}")}"
}
```

###To create IAM Instance Profile:
```
module "instance_profile" {
  source            = "git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-iam.git"
  iam_instance_profile_name = "${var.instance_profile_name}"
  iam_role_name     = "${var.role_name}"
  iam_policy_name   = "${var.iam_instance_profile_policy_name}"
  iam_policy        = "${data.template_file.s3-get-permission-policy.rendered}"
  assume_policy     = "${file(var.role_assumed_policy_file)}"
}
```

###To create KMS Keys:
```
module "iam" {
  source = "git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-iam.git"
  kms_key_alias_name = "kms_alias_name" ex: "398978-test-9,398978-test-10"
  kms_key_description = "key description"ex:"398978-test-9,398978-test-10"
  vpc_contact = "vpc contact"
  global_costcode = "costcode"
  environment = "environment"
  kms_administrators = "iam users"#optional if kms key should have administrators other than root user/admins ex: "398978,398978_temp_user"
}
```

## Output:

| Output Name           | Description                  |
|-----------------------|------------------------------|
| instance_profile_name | Name of the instance profile |
| iam_role_name         | IAM Role Name                |
| iam_role_arn          | IAM Role ARN                 |
| iam_policy_arn        | IAM Policy ARN               |
| access_key_id         | IAM User Access Key ID       |
| secret_key            | IAM User Secret Key          |
| cert_id               | IAM Certificate ID           |
| cert_arn              | IAM Certificate ARN          |
| cert_name             | IAM Certificate Name         |
| kms_key_arn           | kms key arn                  |
| kms_key_id            | kms key id                   |
| kms_key_alias         | kms key alias arn            |
