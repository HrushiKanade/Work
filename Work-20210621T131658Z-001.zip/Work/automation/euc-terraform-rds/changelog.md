## 1.0.2 (6 December 2017)
### Fix
- Removed trailing white space in "final_snapshot_identifier" variable

## 1.0.1 (15 Sep 2017)
### Improvements
- Module supports db parameter group Description.
- Module supports creation of Subnet group Description
- Tags updated to match latest tagging requirements.

## 1.0.0 (14 Sep 2017)
- Initial release
