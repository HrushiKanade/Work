# RDS Module:

## Git Project: git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-rds.git

## Description:

```
This Module is used to provision RDS resource.
```

## Input Variables:

| Variable Name                       | Required | Description                                                                    |
|-------------------------------------|----------|--------------------------------------------------------------------------------|
| vpc_contact                         | Yes      | Used in Tags. Provide the email address that managed this VPC                  |
| global_costcode                     | Yes      | Used in Tags, Provide the Costcode.                                            |
| global_orchestration                | Optional | Default is “terraform”.                                                        |
| global_department                   | Optional | Default is “tio”.                                                              |
| global_subdepartment                | Optional | Default is “euc”                                                               |
| global_country                      | Optional | Default is “gb”                                                                |
| cloud_environment                   | Optional | Default is “aws”                                                               |
| repo_url                            | Optional | Default is "git@gitlab.et-scm.com:tio-euc/euc-terraformcontrol-enterprise.git" |
| euc_tower                           | Optional | Default is “enterprise”                                                        |
| environment                         | Yes      | Provide the Environment(Prod/Pre-Prod).                                        |
| product                             | Yes      | Provide the “aws service name”.                                                |
| subnetgrp-name                      | Yes      | Name of the Subnet Group                                                       |
| subnetgrp-description               | Yes      | Description of the Subnet Group.                                               |
| subnets                             | Yes      | Subnet ID to add to the Subnet Group.                                          |
| db_parameter_group_name             | Yes      | Security Group ID’s to apply to the Elasticache.                               |
| db_parameter_group                  | Yes      | ID of the cluster.                                                             |
| db_parameter_group_description      | Yes      | Defaults to memcache. Accepts input “memcache or redis”                        |
| allocated_storage                   | Yes      | Allocated storage in GB for the RDS.                                           |
| allow_major_version_upgrade         | Optional | Default is false. Accepted inputs are “true or false”                          |
| auto_minor_version_upgrade          | Optional | Default is false. Accepted inputs are “true or false”                          |
| apply_immediately                   | Optional | Default is false. Accepted inputs are “true or false”                          |
| availability_zone                   | Yes      | Availability zone                                                              |
| backup_retention_period             | Optional | Default is “0”.                                                                |
| backup_window                       | Optional |                                                                                |
| character_set_name                  | Yes      | Character Set Name                                                             |
| final_snapshot_identifier           | Optional | Default is false. Accepted inputs are “true or false”                          |
| engine                              | Yes      | RDS Engine                                                                     |
| engine_version                      | Yes      | RDS Engine version                                                             |
| final_snapshot_identifier           | Yes      | Snapshot Name                                                                  |
| iam_database_authentication_enabled | Optional | Default is false. Accepted inputs are “true or false”                          |
| iops                                | Optional | Default is 0.                                                                  |
| kms_key_id                          | Optional | ID of the KMS key.                                                             |
| license_model                       | Optional | Defaults to license-included. Accepts input “license-included or byol”         |
| maintenance_window                  | Yes      | Format "thu:00:11-thu:00:41"                                                   |
| monitoring_interval                 | Optional | Default to “0”                                                                 |
| monitoring_role_arn                 | Yes      | IAM Role ARN to allow monitoring                                               |
| multi_az                            | Optional | Default is false. Accepted inputs are “true or false”                          |
| db_name                             | Optional | Require only if engine-version is “sql-se or oracle-se”                        |
| option_group_name                   | Yes      | Option group to use.                                                           |
| username                            | Yes      | RDS Instance Username                                                          |
| password                            | Yes      | RDS Instance password                                                          |
| publicly_accessible                 | Optional | Default is false. Accepted inputs are “true or false”                          |
| replicate_source_db                 | Optional | Source DB ARN                                                                  |
| skip_final_snapshot                 | Optional | Default is false. Accepted inputs are “true or false”                          |
| snapshot_identifier                 | Optional |                                                                                |
| storage_encrypted                   | Optional | Default is false. Accepted inputs are “true or false”                          |
| storage_type                        | Optional | Default is gp2                                                                 |
| timezone                            | Optional |                                                                                |
| vpc_security_group_ids              | Yes      | Comma separated string of security group id                                    |

## Usage:

```
module "rds" {
  source            = "git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-rds.git"
  auto_minor_version_upgrade = "${var.auto_minor_version_upgrade}"
  allocated_storage = "${var.allocated_storage}"
  availability_zone = "${element(split(",",var.availability_zones), 0)}"
  copy_tags_to_snapshot = "${var.copy_tags_to_snapshot}"
  engine = "${var.engine}"
  engine_version = "${var.engine_version}"
  final_snapshot_identifier = "${var.db_name}-snapshot"
  snapshot_identifier = "${var.snapshot_identifier}"
  instance_class = "${var.instance_class}"
  license_model = "${var.license_model}"
  db_name = "${var.db_name}"
  vpc_security_group_ids = "${element(split(",", data.terraform_remote_state.vpc_state.migration-studio-sg),1)}"
  subnetgrp-name = "${var.subnetgrp-name}"
  subnetgrp-description = "${var.subnetgrp-description}"
  subnets = "${element(split("," , data.terraform_remote_state.vpc_state.spare4_subnet_zone_1), 0)},${element(split("," , data.terraform_remote_state.vpc_state.spare4_subnet_zone_2), 0)}"
  db_parameter_group_name = "${var.db_parameter_group_name}"
  db_parameter_group_description = "${var.db_parameter_group_description}"
  db_parameter_group = "${var.db_parameter_group}"
  maintenance_window = "${var.maintenance_window}"
  backup_window = "${var.backup_window}"
  backup_retention_period = "${var.backup_retention_period}"
  vpc_contact = "${var.vpc_contact}"
  global_costcode = "${var.global_costcode}"
  product = "${var.product_rds}"
  environment = "${var.environment}"
  }
```

## Output:

| Output Name     | Description  |
|-----------------|--------------|
| rds_address     | RDS Address  |
| rds_arn         | RDS ARN      |
| rds_endpoint    | RDS Endpoint |
| rds_id          | RDS ID       |
| rds_username    | RDS Username |
| rds_resource_id | RDS Password |
