## 1.0.2 (23 November 2017)
### Enhancement
- Code change to support force destroy of S3 buckets with objects.

## 1.0.2 (15 November 2017)
### Improvements
- Code change to support creation of buckets with Server access logging

## 1.0.1 (14 November 2017)
### Fix
- Fixed issue with S3 bucket creation

## 1.0.0 (23 October 2017)
- Initial release
