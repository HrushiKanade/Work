# S3 Module:

## Git Project: git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-s3.git

## Description:

```
This Module is used to provision s3 resource:
  •	Module can create S3 bucket with without policy
  •	Module can configure Bucket replication
  •	Module can be used to run external command from our local laptop.
```

## Input Variables:

| Variable Name            | Required | Description                                                                                 |
|--------------------------|----------|---------------------------------------------------------------------------------------------|
| vpc_contact              | Yes      | Used in Tags. Provide the email address that managed this VPC                               |
| global_costcode          | Yes      | Used in Tags, Provide the Costcode.                                                         |
| global_orchestration     | Optional | Default is “terraform”.                                                                     |
| global_department        | Optional | Default is “tio”.                                                                           |
| global_subdepartment     | Optional | Default is “euc”                                                                            |
| global_country           | Optional | Default is “gb”                                                                             |
| cloud_environment        | Optional | Default is “aws”                                                                            |
| repo_url                 | Optional | Default is "git@gitlab.et-scm.com:tio-euc/euc-terraformcontrol-enterprise.git"              |
| euc_tower                | Optional | Default is “enterprise”                                                                     |
| environment              | Yes      | Provide the Environment(Prod/Pre-Prod).                                                     |
| product                  | Yes      | Provide the “aws service name”.                                                             |
| account_number           | Yes      | AWS Account Number                                                                          |
| replication_role         | Optional | Replication Role ARN. Required for S3 bucket replication configuration.                     |
| replication_id           | Optional | Name of the replication.                                                                    |
| replication_prefix       | Optional | Default is all.                                                                             |
| destination_bucket_arn   | Optional | ARN of the destination bucket                                                               |
| storage_class            | Optional | Default is STANDARD.                                                                        |
| script_execution_req     | Optional | Set to Yes only if script execution is required.                                            |
| command                  | Optional | Command to execute                                                                          |
| new_bucket_policy        | Optional | Policy for the S3 bucket                                                                    |
| replication_req          | Optional | Set to Yes to enable bucket replication                                                     |
| static_bucket_name       | Optional | Required if the bucket name is pre-defined.                                                 |
| bucket_name              | Optional | Name of the S3 bucket if already exists                                                     |
| acl                      | Optional | Defaults to Private.                                                                        |
| versioning               | Optional | Defaults to true. Accepts “true or false”                                                   |
| bucket_policy            | Optional | Accepts Bucket policy.                                                                      |
| new_s3_bucket            | Optional | Set to yes if the bucket_name is a new bucket                                               |
| force_destroy            | Optional | Defaults to false. Accepts value “true or false”                                            |
| provider_region          | Optional | Required only for S3 bucket replication configuration. Should be the primary bucket region. |
| provider_account_profile | Optional | Should be Source bucket aws profile.                                                        |

##Usage:

```
module "s3_bucket" {
  source             = "git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-s3.git"
  new_s3_bucket      = "yes"
  static_bucket_name = "${var.bucket_name}-backup"
  bucket_policy      = "${data.template_file.s3_bucket_policy.rendered}"
  force_destroy      = "true"
  vpc_contact        = "${var.vpc_contact}"
  global_costcode    = "${var.global_costcode}"
  environment        = "${var.environment}"
  product            = "${var.product}"
}
```

## Output:

| Output Name   | Description   |
|---------------|---------------|
| s3_bucket_id  | S3 Bucket ID  |
| s3_bucket_arn | S3 Bucket ARN |
