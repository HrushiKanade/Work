##2.0.7 (20 Novemeber 2017)
### Fix
- Included life cycle rule to ignore_change on VPC endpoint

##2.0.6 (25 September 2017)
### Fix
- Updated Subnet Name to match the latest naming conventions.

##2.0.5 (22 September 2017)
### Improvements
- Merged VPN Module with VPC Module.

##2.0.4 (11 August 2017)
### Fix
- Updated Ephermal Port range in NACL.

##2.0.4 (09 August 2017)
### Improvements
- Code included to support DHCP option set creation.

##2.0.3 ( 07 August 2017)
### Fix
- Removed code that creates duplicate non-propagated VGW rules.

##2.0.2 (20 July 2017)
### Improvements
- Include Conditional for DC route creation.
- Include additional Tag for VPC Module.

##2.0.1 (19 July 2017)
### Improvements
- Include Conditional to support creation of routes for VGW.
- Include additional Tag for VPC Module.

## 2.0.0 (14 July 2017)
### Major Release
- Logic change to support creation of additional subnets.
- Logic to support creation of resources optionally using conditionals.

## 1.0.2 (24 May 2017)
### Improvements
- Included Elsevier CIDR Ranges in module output.

## 1.0.1 (19 May 2017)
### Improvements
- Included Module Outputs.

## 1.0.0 (12 May 2017)
- Initial release
