#	VPC Module:

##	Git Project: git@gitlab.et-scm.com:tio-euc/euc-terraform-vpc.git

##	Description:

```
This Module is used to provision VPC with
  •	Optional Public /Private subnets creation. (Spread across max of two availability zone)
  •	Pre-Defined Network ACL’s
  •	Create VPN optionally if required
  •	Create NAT Gateways Optionally if Public Subnet is provisioned,
  •	Create Custom DHCP Option Set for naming resolution using On-Premise Nameservers.
  •	Create S3 Endpoint if private subnet is provisioned.
```

##	VPC Creation Logic

This section describes the resources created on each scenario.

### VPC with Private Subnets Only:
      •	Subnets Can be created only across two Availability Zone.
      •	Private Network ACL.
      •	S3-Endpoint.
      •	Private Routes.
      •	Route 53 Private Hosted Zone
      •	DHCP option set.
      •	Virtual Private Gateway
      •	Optional VPN.

### VPC with Private and Public Subnet:
      •	Subnets will be created only across two Availability Zone.
      •	Public Subnet will be created across two Availability Zone.
      •	Public and Private Network ACL.
      •	S3-Endpoint.
      •	Public and Private Routes.
      •	Route 53 Private Hosted Zone
      •	DHCP option set.
      •	Internet Gateway
      •	Virtual Private Gateway.
      •	Two NAT Gateways one in each availability zone.
      •	Optional VPN.

## Input Variables:

| Variable Name            | Required | Description                                                                                             |
|--------------------------|----------|---------------------------------------------------------------------------------------------------------|
| vpc_contact              | Yes      | Used in Tags. Provide the email address that managed this VPC                                           |
| global_costcode          | Yes      | Used in Tags, Provide the Costcode.                                                                     |
| global_orchestration     | Optional | Default is “terraform”.                                                                                 |
| global_department        | Optional | Default is “tio”.                                                                                       |
| global_subdepartment     | Optional | Default is “euc”                                                                                        |
| global_country           | Optional | Default is “gb”                                                                                         |
| cloud_environment        | Optional | Default is “aws”                                                                                        |
| repo_url                 | Optional | Default is "git@gitlab.et-scm.com:tio-euc/euc-terraformcontrol-enterprise.git"                          |
| euc_tower                | Optional | Default is “enterprise”                                                                                 |
| product                  | Yes      | Provide the “aws service name”.                                                                         |
| environment              | Yes      | Provide the Environment(Prod/Pre-Prod).                                                                 |
| vpc_cidr                 | Yes      | CIDR Range of VPC.                                                                                      |
| phz_domain               | Yes      | Private Hosted Zone Domain Name                                                                         |
| domain_name_servers      | Yes      | Comma separated string of name servers.                                                                 |
| all_cidr_blocks          | Optional | Default is “0.0.0.0/0”                                                                                  |
| elsevier_cidr_blocks     | Optional | Default is "198.176.80.0/20,198.185.18.0/24, 10.185.28.0/22,10.48.64.0/21,172.29.0.0/16, 145.36.0.0/16" |
| vpc_propagating_vgws     | Optional | For external VGW’s that needs propagation. Should be a comma separated string.                          |
| availability_zones       | Yes      | Comma separated string. Maximum of two availability zone supported.                                     |
| public_subnets_1a        | Optional | Comma separated string. Gets created in availability Zone 1                                             |
| public_subnets_1b        | Optional | Comma separated string. Gets created in availability Zone 2                                             |
| public_subnets_1a_names  | Optional | Defaults to public1a.                                                                                   |
| public_subnets_1b_names  | Optional | Defaults to public1b.                                                                                   |
| private_subnets_1a       | Optional | Comma separated string. Gets created in availability Zone 1                                             |
| private_subnets_1b       | Optional | Comma separated string. Gets created in availability Zone 2                                             |
| private_subnets_1a_names | Optional | Defaults to private1a.                                                                                  |
| private_subnets_1b_names | Optional | Defaults to private1b.                                                                                  |
| private_subnets_2a       | Optional | Comma separated string. Gets created in availability Zone 1                                             |
| private_subnets_2b       | Optional | Comma separated string. Gets created in availability Zone 2                                             |
| private_subnets_2a_names | Optional | Defaults to private 2a.                                                                                 |
| private_subnets_2b_names | Optional | Defaults to private 2b.                                                                                 |
| private_subnets_3a       | Optional | Comma separated string. Gets created in availability Zone 1                                             |
| private_subnets_3b       | Optional | Comma separated string. Gets created in availability Zone 2                                             |
| private_subnets_3a_names | Optional | Defaults to private 3a.                                                                                 |
| private_subnets_3b_names | Optional | Defaults to private 3b.                                                                                 |
| private_subnets_4a       | Optional | Comma separated string. Gets created in availability Zone 1                                             |
| private_subnets_4b       | Optional | Comma separated string. Gets created in availability Zone 2                                             |
| private_subnets_4a_names | Optional | Defaults to private 4a.                                                                                 |
| private_subnets_4b_names | Optional | Defaults to private 4b.                                                                                 |
| private_subnets_5a       | Optional | Comma separated string. Gets created in availability Zone 1                                             |
| private_subnets_5b       | Optional | Comma separated string. Gets created in availability Zone 2                                             |
| private_subnets_5a_names | Optional | Defaults to private 5a.                                                                                 |
| private_subnets_5b_names | Optional | Defaults to private 5b.                                                                                 |
| private_subnets_6a       | Optional | Comma separated string. Gets created in availability Zone 1                                             |
| private_subnets_6b       | Optional | Comma separated string. Gets created in availability Zone 2                                             |
| private_subnets_6a_names | Optional | Defaults to private 6a.                                                                                 |
| private_subnets_6b_names | Optional | Defaults to private 6b.                                                                                 |
| private_subnets_7a       | Optional | Comma separated string. Gets created in availability Zone 1                                             |
| private_subnets_7b       | Optional | Comma separated string. Gets created in availability Zone 2                                             |
| private_subnets_7a_names | Optional | Defaults to private 7a.                                                                                 |
| private_subnets_7b_names | Optional | Defaults to private 7b.                                                                                 |
| private_subnets_8a       | Optional | Comma separated string. Gets created in availability Zone 1                                             |
| private_subnets_8b       | Optional | Comma separated string. Gets created in availability Zone 2                                             |
| private_subnets_8a_names | Optional | Defaults to private 8a.                                                                                 |
| private_subnets_8b_names | Optional | Defaults to private 8b.                                                                                 |
| dc_subnets_1a            | Optional | Comma separated string. Gets created in availability Zone 1                                             |
| dc_subnets_1b            | Optional | Comma separated string. Gets created in availability Zone 2                                             |
| dc_subnets_1a_names      | Optional | Defaults to private 8a.                                                                                 |
| dc_subnets_1b_names      | Optional | Defaults to private 8b.                                                                                 |
| public_subnet_present    | Optional | Defaults to True. Set to false only if Public subnet is not present.                                    |
| policy                   | Optional | Used by S3 endpoint. Default policy allows all access.                                                  |
| ip_address               | Optional | Used for VPN creation. Pass the Router IP Address. Required for Customer Gateway Provisioning           |
| bgp_asn                  | Optional | Default is 65000. If dynamic routing is configured provide the BGP supplied by network team.            |
| vpn_name                 | Optional | Provide Name of VPN.                                                                                    |
| vpn_type                 | Optional | Default is ipsec.1. Only supported type at this moment is ipsec.1                                       |
| static_route_only        | Optional | Defaults to “0”. Setting the value to “1” will create VPN with Static Routes.                           |
| static_routes            | Optional | Only required if static_route_only is set to “1”. Should be comma separated strings.                    |

## Usage:

```
module "vpc" {
  source = "git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-vpc.git"
  domain_name_servers = "${var.dns_servers}"
  phz_domain  = "${var.domain_name}"
  vpc_contact  = "${var.vpc_contact}"
  global_costcode  = "${var.global_costcode}"
  global_region = "${var.global_region}"
  product  = "${var.product}"
  environment  = "${var.environment}"
  vpc_cidr  = "${var.vpc_cidr}"
  availability_zones = "${var.availability_zones}"
  private_subnets_1a = "${var.private_subnets_1a}" #App_Subnet_zone_1
  private_subnets_1a_names = "${element(var.subnets_name, 0)}"
  private_subnets_1b = "${var.private_subnets_1b}" #App_Subnet_zone_2
  private_subnets_1b_names = "${element(var.subnets_name, 1)}"
  ip_address = "${var.internet_ip_address}"
  bgp_asn = "${var.bgp_asn}"
  vpn_name = "${var.vpn_name}"
  private_subnets_1b_names = "${element(var.subnets_name, 1)}"
  private_subnets_2a = "${var.private_subnets_2a}" #NetEng_Subnet_zone_1
  private_subnets_2a_names = "${element(var.subnets_name, 6)}"
  private_subnets_2b = "${var.private_subnets_2b}" #NetEng_Subnet_zone_2
  private_subnets_2b_names = "${element(var.subnets_name, 7)}"
  public_subnets_1a = "${var.public_subnets_1a}"#Public_Subnet_zone_1
  public_subnets_1a_names = "${element(var.subnets_name, 18)}"
  public_subnets_1b = "${var.public_subnets_1b}"#Public_Subnet_zone_2
  public_subnets_1b_names = "${element(var.subnets_name, 19)}"
  dc_subnets_1a = "${var.dc_subnets_1a}"#dc_subnet_zone_1
  dc_subnets_1a_names = "${element(var.subnets_name, 14)}"
  dc_subnets_1b = "${var.dc_subnets_1b}"#dc_subnet_zone_2
  dc_subnets_1b_names = "${element(var.subnets_name, 15)}"
  private_subnets_3a = "${var.private_subnets_3a}"#Spare1_Subnet_zone_1
  private_subnets_3a_names = "${element(var.subnets_name, 2)}"
  private_subnets_3b = "${var.private_subnets_3b}"#Spare1_Subnet_zone_2
  private_subnets_3b_names = "${element(var.subnets_name, 3)}"
  private_subnets_4a = "${var.private_subnets_4a}"#Spare2_Subnet_zone_1
  private_subnets_4a_names = "${element(var.subnets_name, 4)}"
  private_subnets_4b = "${var.private_subnets_4b}"#Spare2_Subnet_zone_2
  private_subnets_4b_names = "${element(var.subnets_name, 5)}"
  private_subnets_5a = "${var.private_subnets_5a}"#Spare3_Subnet_zone_1
  private_subnets_5a_names = "${element(var.subnets_name, 8)}"
  private_subnets_5b = "${var.private_subnets_5b}"#Spare3_Subnet_zone_2
  private_subnets_5b_names = "${element(var.subnets_name, 9)}"
  private_subnets_6a = "${var.private_subnets_6a}"#Spare4_Subnet_zone_1
  private_subnets_6a_names = "${element(var.subnets_name, 10)}"
  private_subnets_6b = "${var.private_subnets_6b}"#Spare4_Subnet_zone_2
  private_subnets_6b_names = "${element(var.subnets_name, 11)}"
  private_subnets_7a = "${var.security_subnets_1a}"#security_Subnet_zone_1
  private_subnets_7b = "${var.security_subnets_1b}"#security_Subnet_zone_2
  private_subnets_8a = "${var.devops_subnets_1a}"#devops_Subnet_zone_1
  private_subnets_8b = "${var.devops_subnets_1b}"#devops_Subnet_zone_2
  public_subnet_present = "false" <<Required only if Public subnet is not present>>
}
```

## Inputs:

```
global_account_number = "##############"
global_region = "#######"
global_account_profile = "##########"
vpc_contact = "##########"
global_costcode = "##########"
product = "##########"
environment = "##########"
vpc_cidr = "10.153.0.0/20"
availability_zones = "eu-west-1a,eu-west-1b"
public_subnets_1a = "10.153.11.0/25"
public_subnets_1b = "10.153.11.128/25"
dc_subnets_1a = "10.153.10.128/26"
dc_subnets_1b = "10.153.10.192/26"
security_subnets_1a = "10.153.10.0/26"
security_subnets_1b = "10.153.10.64/26"
devops_subnets_1a = "10.153.9.0/25"
devops_subnets_1b = "10.153.9.128/25"
private_subnets_1a = "10.153.0.0/22"
private_subnets_1b = "10.153.4.0/22"
private_subnets_2a = "10.153.8.0/25"
private_subnets_2b = "10.153.8.128/25"
private_subnets_3a = "10.153.12.0/24"
private_subnets_3b = "10.153.13.0/24"
private_subnets_4a = "10.153.14.0/25"
private_subnets_4b = "10.153.14.128/25"
private_subnets_5a = "10.153.15.0/26"
private_subnets_5b = "10.153.15.64/26"
private_subnets_6a = "10.153.15.128/26"
private_subnets_6b = "10.153.15.192/26"
subnets_name = ["app-subnet-az1a","app-subnet-az1b","neteng-subnet-az1a","neteng-subnet-az1b","elb-subnet-az1a","elb-subnet-az1b","rds-subnet-az1a","rds-subnet-az1b"]
dns_servers = "####################"
domain_name = "els.vpc.local"
elsevier_internal_subnets = "######################"
```

## Output:

| Output Name                    | Description                 |
|--------------------------------|-----------------------------|
| nat_eip                        | Public IP of NAT Gateway    |
| inbound_http_security_group    | Security Group ID           |
| inbound_https_security_group   | Security Group ID           |
| inbound_rdp_security_group     | Security Group ID           |
| phz_zone_id                    | Route 53 Hosted Zone ID     |
| dc_route_table                 | Route Table ID              |
| private_route_table            | Route Table ID              |
| public_route_table             | Route Table ID              |
| subnets_public_az_1            | Subnet ID’s                 |
| subnets_public_az_1_cidr       | Subnet CIDR Range           |
| subnets_public_az_2            | Subnet ID’s                 |
| subnets_public_az_2_cidr       | Subnet CIDR Range           |
| subnets_private_az_1           | Subnet ID’s                 |
| subnets_private_az_1_cidr      | Subnet CIDR Range           |
| subnets_private_az_2           | Subnet ID’s                 |
| subnets_private_az_2_cidr      | Subnet CIDR Range           |
| subnets_dc_az_1                | Subnet ID’s                 |
| subnets_dc_az_1_cidr           | Subnet CIDR Range           |
| subnets_dc_az_2                | Subnet ID’s                 |
| subnets_dc_az_2_cidr           | Subnet CIDR Range           |
| subnets_private_az_1_1         | Subnet ID’s                 |
| subnets_private_az_1_1_cidr    | Subnet CIDR Range           |
| subnets_private_az_1_2         | Subnet ID’s                 |
| subnets_private_az_1_2_cidr    | Subnet CIDR Range           |
| subnets_private_az_2_1         | Subnet ID’s                 |
| subnets_private_az_2_1_cidr    | Subnet CIDR Range           |
| subnets_private_az_2_2         | Subnet ID’s                 |
| subnets_private_az_2_2_cidr    | Subnet CIDR Range           |
| subnets_private_az_3_1         | Subnet ID’s                 |
| subnets_private_az_3_1_cidr    | Subnet CIDR Range           |
| subnets_private_az_3_2         | Subnet ID’s                 |
| subnets_private_az_3_2_cidr    | Subnet CIDR Range           |
| subnets_private_az_4_1         | Subnet ID’s                 |
| subnets_private_az_4_1_cidr    | Subnet CIDR Range           |
| subnets_private_az_4_2         | Subnet ID’s                 |
| subnets_private_az_4_2_cidr    | Subnet CIDR Range           |
| subnets_private_az_5_1         | Subnet ID’s                 |
| subnets_private_az_5_1_cidr    | Subnet CIDR Range           |
| subnets_private_az_5_2         | Subnet ID’s                 |
| subnets_private_az_5_2_cidr    | Subnet CIDR Range           |
| subnets_private_az_6_1         | Subnet ID’s                 |
| subnets_private_az_6_1_cidr    | Subnet CIDR Range           |
| subnets_private_az_6_2         | Subnet ID’s                 |
| subnets_private_az_6_2_cidr    | Subnet CIDR Range           |
| subnets_private_az_7_1         | Subnet ID’s                 |
| subnets_private_az_7_1_cidr    | Subnet CIDR Range           |
| subnets_private_az_7_2         | Subnet ID’s                 |
| subnets_private_az_7_2_cidr    | Subnet CIDR Range           |
| vgw_id                         | Virtual gateway ID          |
| vpc_id                         | VPC ID                      |
| vpc_cidr                       | VPC CIDR                    |
| s3-endpoint-id                 | S3Endpoint ID               |
| vpn_id                         | VPN ID                      |
| customer_gateway_id            | Customer Gateway ID         |
| customer_gateway_configuration | VPN Configuration           |
| tunnel1_address                | VPN Tunnel 1 IP Address     |
| tunnel1_preshared_key          | VPN Tunnel 1 Pre-Shared Key |
| tunnel2_address                | VPN Tunnel 2 IP Address     |
| tunnel2_preshared_key          | VPN Tunnel 2 Pre-Shared Key |
