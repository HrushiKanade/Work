# EC2 Module:

## Git Project: git@gitlab.et-scm.com:tio-euc/euc-terraform-ec2.git

## Description:

```
This Module is used to create EC2 resource. Using this module, we can launch
		•	Single EC2 instance
		•	Group of EC2 instances.
		•	Instance with Static IP/Dynamic IP/ Multiple Private IP associated to a single NIC.
```

## Input Variables:

| Variable Name                 | Required | Description                                                                                                                                                   |
|-------------------------------|----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------|
| ami_id                        | Yes      | Accepts ami_id as a comma separated value if more than one instance should be provisioned and each use different AMI.                                         |
| instance_type                 | Yes      | Type of instance to be provisioned. Accepts Instance type as a comma separated value if each instance will have different instance types.                     |
| associate_public_ip           | Optional | Default to False. If set True, will associate Public IP to the launched instance                                                                              |
| private_ip                    | Optional | Accepts count of private_ip to be associated to the NIC or provide Static IP address as a comma separated string.                                             |
| iam_instance_profile          | Optional | Should be used only if IAM Instance profile to be attached to an instance.                                                                                    |
| subnet                        | Yes      | Subnet should be provided for each instance. Should be a Comma separated string.                                                                              |
| security_group                | Yes      | Should be a comma separated string and each instance should map to its own Security group. Multiple Security Group(Up to 5) can be attached to each instance. |
| root_volume_type              | Optional | Accepts Default to GP2. Accepted values are "gp2", or "io1” or “standard”. Should be comma separated string                                                   |
| root_volume_size              | Optional | Defaults to 50GB.                                                                                                                                             |
| delete_on_termination         | Optional | Defaults to True. This option deletes the volume on instance termination.                                                                                     |
| key_name                      | Yes      | Key Pair associated to the instance.                                                                                                                          |
| user_data                     | Optional | command to get executed post instance provisioning.                                                                                                           |
| instance_name                 | Yes      | Name of the instance.                                                                                                                                         |
| instance_count                | Yes      | Number of instance to be provisioned in a single module call.                                                                                                 |
| network_delete_on_termination | Optional | Defaults to False. Do not override the value.                                                                                                                 |
| ebs_optimized                 | Optional | Default to False. Value can be set to true for only for instances that supports ebs optimised volumes.                                                        |
| vpc_contact                   | Yes      | Used in Tags. Provide the email address that managed this VPC                                                                                                 |
| global_costcode               | Yes      | Used in Tags, Provide the Costcode.                                                                                                                           |
| global_orchestration          | Optional | Default is “terraform”.                                                                                                                                       |
| global_department             | Optional | Default is “tio”.                                                                                                                                             |
| global_subdepartment          | Optional | Default is “euc”                                                                                                                                              |
| global_country                | Optional | Default is “gb”                                                                                                                                               |
| cloud_environment             | Optional | Default is “aws”                                                                                                                                              |
| repo_url                      | Optional | Default is "git@gitlab.et-scm.com:tio-euc/euc-terraformcontrol-enterprise.git"                                                                                |
| euc_tower                     | Optional | Default is “enterprise”                                                                                                                                       |
| product                       | Yes      | Provide the “aws service name”.                                                                                                                               |
| environment                   | Yes      | Provide the Environment(Prod/Pre-Prod).                                                                                                                       |
| application_classification    | Optional | Default is “Green”. Please provide classification based on the application.                                                                                   |
| schedule_shutdown             | Optional | Default is “No”, Should be used only if the instance shutdown should be managed by Power_Schedule Lambda                                                      |
| schedule_start                | Optional | input should be of the format "(mon-fri)|06:30"                                                                                                               |
| schedule_stop                 | Optional | input should be of the format "(mon-fri)|18:30"                                                                                                               |
| cpm_backup                    | Optional | If CPM Managed backup is enabled, then provide the policy name from CPM.                                                                                      |
| cpm_backup_volume             | Optional | If CPM Managed Volume backup is enabled, then provide the policy name from CPM.                                                                               |

## Usage:

```
module "instance" {
  source = "git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-ec2.git"
  ami_id   = “ami_id”<< single instance/multiple instance using same ami-id >> or "ami_id1,ami_id2" <<multiple instance provisioning and each with different   ami_id>>
  instance_count  = "1"<<number of instance to be provisioned>>
  root_volume_size = "50"<<each provisioned instance will have 50 GB root volume size>>
	                   “50,75” <<two instance provisioned with 1st instance 50 and 2nd 75>>
  subnet = “subnet1” <<is all instances should be provisioned on same subnet>>
	    		 “subnet1, subnet2” <<if each instance will be provisioned in different subnet>>
  security_group = "sg-id1, sg-id2"<<if same security groups should be attached to all instances.
	                 “sg-id1, sg-id2@sg-id1, sg-id2” <<if separate SG should be attached to each instance>>
 instance_type = "instance-type" << single instance/multiple instance using same instance type >>
		  					 “instance-type1, instance-type2” <<two instance with different instance type>>
  private_ip =   "2"<<provision two private ip’s for each instance>>
                 “2@3” <<Provision two private ip’s for first instance and three for second 		 instance>>
                 “ip address1@ip address 2” <<two instances with static ip address
                 “ip add1, ip add2@ip add 3, ip add 4” <<two instances with two static ip’s 		 each>>
  key_name = "key pair name"<<Provide the keypair name>>
  instance_name = "instance_name1, instance_name 2"
  vpc_contact = "vpc_contact"
  global_costcode = global_costcode"
  product = "product"
  environment = "environment"
  schedule_shutdown = "no” or “yes"<<Only two values are accepted>>
  schedule_start = "(mon-fri)|06:30@(mon-fri)|07:30"<<two instance with its own start time>>
                   "(mon-fri)|06:30”<<all instances will use the same value>>
  schedule_stop = "(mon-fri)|06:30@(mon-fri)|07:30"<<two instance with its own start time>>
                  "(mon-fri)|06:30”<<all instances will use the same value>>
  cpm_backup = “backup policy 1, backup policy 2"<<each instance with its own backup 			 policy>>
               “backup policy” <<all instances provisioned use the same backup policy”
}
```

## Output:

| Output Name       | Description                          |
|-------------------|--------------------------------------|
| instance_id       | Instance ID as a concatenated string |
| availability_zone | availability zone for each instance. |
| primary_eni       | ENI of the primary interface.        |
