## 1.0.0 (31 October 2018)
- Initial release