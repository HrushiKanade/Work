## 1.0.0 (30 November 2018)
- Initial release