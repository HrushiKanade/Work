## 1.0.8 (30 Oct 2018)
### Fix
- Included feature to create ALB with or without access logs.

## 1.0.7 (1 Dec 2017)
### Fix
- Added lifecycle rule to ignore certificate changes.

## 1.0.6 (31 October 2017)
### Fix
- Fixed Interpolation Logic in ALB Target group attachment.

## 1.0.5 (14 August 2017)
### Improvement
- Enable Access Logs

## 1.0.4 (9 August 2017)
### Improvement
- Add tags to ALB Module

## 1.0.3 (5 July 2017)
### Improvement
- Updated Listener health check variables.

## 1.0.2 (19 June 2017)
### Fix
- Fixed issue with count interpolation on Target group attachment.

## 1.0.1 (16 June 2017)
### Fix
- Moved ALB Target Attachment to a separate Module to resolve issue with count.

## 1.0.0 (16 June 2017)
- Initial release
