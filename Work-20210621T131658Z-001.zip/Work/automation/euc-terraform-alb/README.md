# ALB Module:

## Git Project: git@gitlab.et-scm.com:tio-euc/euc-terraform-alb.git

## Description:

```
This Module is used to provision ALB:
			•	Module supports creation of both Internal and External ALB’s.
			•	Supports creation of ALB Target Groups.
			•	Supports Creation of ALB Listeners and its associated routing rules.
```

## Input Variables:

| Variable Name          | Required | Description                                                                                |
|------------------------|----------|--------------------------------------------------------------------------------------------|
| vpc_contact            | Yes      | Used in Tags. Provide the email address that managed this VPC                              |
| global_costcode        | Yes      | Used in Tags, Provide the Costcode.                                                        |
| global_orchestration   | Optional | Default is “terraform”.                                                                    |
| global_department      | Optional | Default is “tio”.                                                                          |
| global_subdepartment   | Optional | Default is “euc”                                                                           |
| global_country         | Optional | Default is “gb”                                                                            |
| cloud_environment      | Optional | Default is “aws”                                                                           |
| repo_url               | Optional | Default is "git@gitlab.et-scm.com:tio-euc/euc-terraformcontrol-enterprise.git"             |
| euc_tower              | Optional | Default is “enterprise”                                                                    |
| environment            | Yes      | Provide the Environment(Prod/Pre-Prod).                                                    |
| alb_name               | Yes      | Name of the ALB                                                                            |
| Subnet_id              | Yes      | Accepts Subnet ID’s as a comma separated string.                                           |
| instance_id            | Yes      | Accepts Instance ID’s as a comma separated string                                          |
| security_group_id      | Yes      | Accepts Security Group ID’s as a comma separated string                                    |
| is_internal            | Optional | Defaults to True. Overriding to false will provision external ELB.                         |
| certificate_arn        | Optional | SSL certificate ARN. Required only if listener protocol is HTTPS.                          |
| bucket_name            | Yes      | Bucket name where Access logs should be stored                                             |
| bucket_prefix          | Yes      | Path where logs should be stored in S3 Bucket                                              |
| interval               | Optional | Default to 30 seconds. Health check interval.                                              |
| ip_address_type        | Optional | Defaults to ipv4                                                                           |
| idle_timeout           | Optional | Defaults to 300 Seconds                                                                    |
| termination_protection | Optional | Defaults to False                                                                          |
| alb_target_group_name  | Optional | ALB target group name. comma separated string.                                             |
| port                   | Optional | Defaults to port 8080.                                                                     |
| protocol               | Optional | Defaults to “HTTP” Accepts “HTTP or HTTPS”                                                 |
| vpc_id                 | Yes      | VPC ID to create the ALB.                                                                  |
| deregistration_delay   | Optional | Defaults to 300 seconds.                                                                   |
| type                   | Optional | Default is lb_cookie. It is the only supported type.                                       |
| cookie_duration        | Optional | Default is 86400. Accepted value will be anywhere between 120 to 86400 seconds.            |
| enabled                | Optional | Defaults to True, this option is to enable cookie duration. Accepted value “true or false” |
| path                   | Optional | Health check path. Default is “/healthcheck.html”                                          |
| traffic_port           | Optional | Default is traffic-port                                                                    |
| health_check_protocol  | Optional | Default is HTTP. Accepted values are HTTP or HTTPS.                                        |
| timeout                | Optional | Default to 5. This is for health check timeout in seconds.                                 |
| healthy_threshold      | Optional | Default to 5. This is for health check try times before marking instance healthy.          |
| unhealthy_threshold    | Optional | Default to 2. This is for health check try times before marking instance unhealthy.        |
| matcher                | Optional | Default is 200. This is the health check return code.                                      |
| alb_arn                | Optional | Arn of the provisioned alb.                                                                |
| listener_ports         | Optional | Defaults to port 8080.                                                                     |
| listener_protocol      | Optional | Defaults to “HTTP” Accepts “HTTP or HTTPS”                                                 |
| ssl_policy             | Optional | Defaults to ELBSecurityPolicy-2015-05                                                      |
| target_group_arn       | Optional | ARN of the Target Group.                                                                   |
| target_type            | Optional | Default is forward.                                                                        |
| instance_id            | Yes      | Instance id to attach to each target group                                                 |
| instance_port          | Yes      | Port for listener to communicate with instance                                             |
| instance_id_count      | Yes      | Count of instance to attach to Target group.                                               |
| priority               | Yes      | Listener Rules Priority                                                                    |
| listener_arn           | Yes      | ARN of the listener                                                                        |
| listener_rule_field    | Optional | Defaults to host-header                                                                    |
| listener_rule_value    | Yes      | Rule number for Listener.                                                                  |
| product                | Yes      | Provide the “aws service name”.                                                            |

##	Usage:

```
module "alb" {
  source = "git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-alb.git"
  alb_name = "alb_name"
  security_group_id = "Security Group ID"
  subnet_id = “Subnet ID"
  bucket_name = "S3 Bucket Name"
  bucket_prefix = "S3 Bucket Path" #tfstate/tio-euc-production-apac-main.tfstate
  alb_target_group_name = "alb target group name"
  vpc_id = "VPC ID"
 	listener_ports = "Listener Port"
  listener_protocol =” HTTP or HTTPS"
  instance_id_count = “Instance Count” #count of instance
  instance_id = "Instance_ID” #instance id comma separated strings.
  instance_port = "instance port"
  vpc_contact = "vpc contact"
  global_costcode = "costcode"
  product = "product"
  environment = "environment"
  certificate_arn = "ARN of the Certificate"
}
```
```
module "jamf_listener" {
  source              = "git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-alb.git"
  priority            = "priority"
  listener_arn        = "arn of the listener"
  target_group_arn    = "arn of the target group"
  listener_rule_value = "listener rule"
  vpc_contact = "vpc contact"
  global_costcode = "costcode"
  product = "product"
  environment = "environment"
}
```

## Output:

| Output Name       | Description       |
|-------------------|-------------------|
| alb_arn           | ID of the ALB     |
| alb_dns           | DNS of ALB        |
| target_group_id   | Target Group ID   |
| target_group_arn  | Target Group ARN  |
| alb_listener_id   | ALB Listener ID   |
| alb_attachment_id | ALB Attachment ID |
