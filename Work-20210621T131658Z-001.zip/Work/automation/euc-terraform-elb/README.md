# ELB Module:

## Git Project: git@gitlab.et-scm.com:tio-euc/euc-terraform-elb.git

## Description:

```
This Module is used to provision ELB:
		•	Module supports creation of both Internal and External ELB’s.
		•	Supports Enabling Access logs for the S3 Bucket.
		•	Supports maximum of 10 Listeners creation per ELB
```

##Input Variables:

| Variable Name               		 | Required | Description                                                                                                                   |
|-----------------------------		 |----------|-------------------------------------------------------------------------------------------------------------------------------|
| vpc_contact                 		 | Yes      | Used in Tags. Provide the email address that managed this VPC                                                                 |
| global_costcode             		 | Yes      | Used in Tags, Provide the Costcode.                                                                                           |
| global_orchestration        		 | Optional | Default is “terraform”.                                                                                                       |
| global_department           		 | Optional | Default is “tio”.                                                                                                             |
| global_subdepartment        		 | Optional | Default is “euc”                                                                                                              |
| global_country              		 | Optional | Default is “gb”                                                                                                               |
| cloud_environment           		 | Optional | Default is “aws”                                                                                                              |
| repo_url                    		 | Optional | Default is "git@gitlab.et-scm.com:tio-euc/euc-terraformcontrol-enterprise.git"                                                |
| euc_tower                   		 | Optional | Default is “enterprise”                                                                                                       |
| product                     		 | Yes      | Provide the “aws service name”.                                                                                               |
| environment                 		 | Yes      | Provide the Environment(Prod/Pre-Prod).                                                                                       |
| elb_name                    		 | Yes      | Name of the ELB.                                                                                                              |
| subnets                     		 | Yes      | Accepts Subnet ID’s as a comma separated string.                                                                              |
| instance_id                 		 | Yes      | Accepts Instance ID’s as a comma separated string                                                                             |
| security_group              		 | Yes      | Accepts Security Group ID’s as a comma separated string                                                                       |
| is_internal                 		 | Optional | Defaults to True. Overriding to false will provision external ELB.                                                            |
| health_check_port           		 | Yes      | Accepts health check port as a string.                                                                                        |
| instance_listener_port      		 | Yes      | Instance Listener Port as a comma separated string. Supports up to 10 listener ports.                                         |
| instance_listener_protocol  		 | Yes      | Instance Listener Protocol as a comma separated string supports up to 10 protocols. Accepted values “TCP, HTTP, HTTPS or SSL” |
| elb_listener_port           		 | Yes      | Comma separated string of elb listener port                                                                                   |
| ssl_certificate_id          		 | Optional | SSL certificate ARN. Required only if listener protocol is HTTPS.                                                             |
| bucket_name                 		 | Yes      | Bucket name where Access logs should be stored                                                                                |
| bucket_prefix               		 | Yes      | Path where logs should be stored in S3 Bucket                                                                                 |
| interval                    		 | yes      | Interval in which the logs should be written to S3.                                                                           |
| cross_zone_load_balancing   		 | Optional | Defaults to True                                                                                                              |
| idle_timeout                		 | Optional | Defaults to 60 Seconds                                                                                                        |
| connection_draining         		 | Optional | Defaults to False                                                                                                             |
| connection_draining_timeout 		 | Optional | Defaults to 300 Seconds                                                                                                       |
| health_check_healthy_threshold   | Optional | Defaults to 5 times.                                                                                                        	|
| health_check_unhealthy_threshold | Optional | Defaults to 2 times.                                                                                                          |
| health_check_timeout             | Optional | Defaults to 10 Seconds.																																																			  |
| health_check_interval            | Optional | Defaults to 30 Seconds.                                                                                                       |

## Usage:

```
module "els-jds-001_elb" {
  source = "git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-elb.git"
  subnets = “subnet1, subnet2”
  instance_id =” instance_id1, instance_id2"
  security_group = "Security Group ID1, Security Group ID1"
  is_internal = “true or false"
  elb_name = “elb name"
  bucket_name = "S3 Bucket Name"
  bucket_prefix = "S3 Bucket Path"
  interval = "Interval in seconds"
  health_check_port = "health check port"
  instance_listener_port = "instance listener port"
  instance_listener_protocol = "HTTP or HTTPS or TCP or SSL"
  elb_listener_port = “elb listener port”
  elb_listener_protocol = " HTTP or HTTPS or TCP or SSL”
  vpc_contact = "vpc contact email"
  global_costcode = "cost code}"
  product = "elb"
  environment = "prod or pre-prod"
}
```

## Output:

| Output Name | Description   |
|-------------|---------------|
| elb_id      | ID of the ELB |
| elb_dns     | DNS of ELB    |
