## 1.0.8 (30 Oct 2018)
### Fix
- Included feature to create ELB with or without access logs.

## 1.0.6 (12 December 2017)
### Improvements
- Support to override health check parameters.

## 1.0.5 (1 December 2017)
### Improvements
- Support for SSL certificates.

## 1.0.4 (14 August 2017)
### Improvements
- Code to support ELB logging

## 1.0.3 (28 Jun 2017)
### Fix
- Removing product from ELB name to reduce length.

## 1.0.2 (25 May 2017)
### Improvements
- Added Support to create up to 10 ELB listeners.

## 1.0.1 (24 May 2017)
### Improvements
- Adding name variable to ELB name
- Updating ELB name to use hyphens
- removed join on output file.

## 1.0.0 (23 May 2017)
- Initial release
