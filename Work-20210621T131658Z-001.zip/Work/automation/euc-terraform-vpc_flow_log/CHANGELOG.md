## 2.0.0 (23 November 2017)
### Major Release
- Code logic changed to support creation of Fireshose in alternate region.

## 1.0.0 (26 July 2017)
- Initial release
