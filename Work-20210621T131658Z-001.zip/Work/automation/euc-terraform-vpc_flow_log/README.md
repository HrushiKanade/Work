# euc-terraform-vpc_flow_log

Set up VPC Flow Log on a VPC of your choosing. The logs will be streamed via
Kinesis Firehose to an S3 bucket. The idea is to host these logs in a central
loggings account created by the [tio-logs-host module](https://gitlab.et-scm.com/tio-euc/euc-terraform-vpc_flow_log)

## What will this set up

This module should be used when Kinesis firehose is unavailable in the region hosting VPC.

The module will:

* Create a CloudWatch log group to hold the VPC Flow log (name: ```[VPC_id]-Flow-logs```)
* Create IAM role to allow VPC Flow log to write to CloudWatch (name: ```[VPC_id]_VPC_FL_role```),
  this role will have an inline policy that allow it to write to CloudWatch
  (name: ```VPC_FL_to_CW_Policy```)
* Enable VPC Flow Log on the designated VPC and set it to export log the created
  CloudWatch log group
* Create IAM role to allow CloudWatch to deliver log to Kinesis Firehose (name: ```[VPC_id]_CW_to_Kinesis```),
  this role will have an inline policy (name: ```CW_to_Kinesis_Policy```)
* Create a Firehose delivery stream that deliver any incoming logs to the _remote_
  S3 bucket, this delivery stream will take on an IAM role provided to this
  module to gain access to this S3 bucket.
    * Firehose will write the logs with prefix ```/VPC_Flow_logs/[VPC_id]/```
* Create an subscription filter on the CloudWatch log group to direct logs from
  this Log group to the delivery stream
* Create IAM role to allow Kinesis Firehose to write to the _remote_ S3 bucket

**Note**: We set the IAM roles, the CloudWatch log group and Kinesis delivery stream name to include
the VPC id to avoid any collision, since this module might be used multiple times in one AWS account for
different VPCs.

## Usage

```terraform
module "vpc_loggings" {
  source = "git::ssh://git@gitlab.et-scm.com/SecurityRemediation/tio-VPC-flow-log.git?ref=tag"

  flowlog_vpc_id            = "${module.vpc.vpc_id}"
  flowlog_bucket_arn        = "arn:aws:s3:::collected-logs-cm-enterprise-682256580502-us-east-1"
}
```

## Input variables

### Required variables

* ```flowlog_vpc_id``` - The ID of the VPC from which you would like to collect logs
* ```flowlog_bucket_arn``` - The ARN of the bucket where we save the logs

### Optional variables

* ```flowlog_traffic_type``` - Traffic type from the VPC we would want to log, possible values:
  (ALL|ACCEPT|REJECT), default to ```ALL```
* ```flowlog_stream_buffer_interval``` - Buffer interval on the Kinesis Firehose delivery stream in second, default to ```60```
* ```flowlog_stream_buffer_size``` - Buffer size of on the Kinesis Firehose delivery stream in MB, default to ```1```
* ```flowlog_stream_compression_format``` - How should the log be compressed in S3 bucket, possible values: (UNCOMPRESSED|GZIP|ZIP|Snappy),
  default to ```GZIP```
* ```flowlog_log_group_retention``` - How long should the log group hold these logs in
  days, default to ```1```

## Output variables

* ```flow_log_id``` - ID of the VPC flow log we created
* ```log_group_arn``` - ARN of the CloudWatch log group
* ```firehose_stream_arn``` - ARN of the Firehose delivery stream that we
  created
