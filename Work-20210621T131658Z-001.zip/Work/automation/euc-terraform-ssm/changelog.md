## 1.0.0 (28 November 2018)
- Initial release