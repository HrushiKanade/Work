## 1.0.6 (01 December 2017)
### Fix
- Removed KMS_Key_Id variable to fix issue with volume recreation.

## 1.0.5 (30 November 2017)
### Improvements
- support creation of EBS volumes from existing snapshots.

## 1.0.4 (31 August 2017)
### Improvements
- Included CPM Tags to EBS Volume creation resource

## 1.0.3 (07 August 2017)
### Improvements
- Modified EBS Volume attachment based on AWS Documentation
- Included additional ebs volume attachment extension

## 1.0.2 (02 August 2017)
### Improvements
- Included functionality to override attachment ID.
- Included Additional tags

## 1.0.1 (13 July 2017)
### Improvements
- Included Override Conditional On Attachment ID

## 1.0.0 (23 May 2017)
- Initial release
