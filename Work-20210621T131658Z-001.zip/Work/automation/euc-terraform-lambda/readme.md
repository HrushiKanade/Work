# Lambda Module:

## Git Project: git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-lambda.git

## Description:

```
This Module is used to provision Lambda function:
   •	Module supports creation of Cloudwatch rule and Cloudwatch function.
   •	Module supports creation of Lambda function.
```

## Input Variables:

| Variable Name               | Required | Description                                                                    |
|-----------------------------|----------|--------------------------------------------------------------------------------|
| vpc_contact                 | Yes      | Used in Tags. Provide the email address that managed this VPC                  |
| global_costcode             | Yes      | Used in Tags, Provide the Costcode.                                            |
| global_orchestration        | Optional | Default is “terraform”.                                                        |
| global_department           | Optional | Default is “tio”.                                                              |
| global_subdepartment        | Optional | Default is “euc”                                                               |
| global_country              | Optional | Default is “gb”                                                                |
| cloud_environment           | Optional | Default is “aws”                                                               |
| repo_url                    | Optional | Default is "git@gitlab.et-scm.com:tio-euc/euc-terraformcontrol-enterprise.git" |
| euc_tower                   | Optional | Default is “enterprise”                                                        |
| environment                 | Yes      | Provide the Environment(Prod/Pre-Prod).                                        |
| product                     | Yes      | Provide the “aws service name”.                                                |
| cloudwatch_rule_name        | Optional | Provide the Cloudwatch rule name                                               |
| cloudwatch_rule_description | Optional | Provide the Cloudwatch rule description                                        |
| schedule_expression         | Optional | Cloudwatch events schedule expression.                                         |
| cloudwatch_rule_arn         | Optional | If Cloudwatch rule already exists provide the arn                              |
| input_json                  | Optional | Provide the json input for Cloudwatch rule.                                    |
| lambda_filename             | Yes      | Provide the Lambda filename                                                    |
| lambda_file_path            | Yes      | Provide the Lambda file path                                                   |
| lambda_function_name        | Yes      | Provide the lambda function name.                                              |
| lambda_description          | Yes      | Provide the Lambda function description                                        |
| lambda_role                 | Yes      | Provide the Lambda Role ARN                                                    |
| lambda_runtime              | Optional | Defaults to python3.6                                                          |
| lambda_memory_size          | Optional | Defaults to memory size 1536. Size in MB.                                      |
| lambda_timeout              | Optional | Defaults to timeout 300. Timeout should be in seconds.                         |

## Usage:

```
module "lambda" {
  source = "git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-lambda.git"
  vpc_contact = "vpc contact"
  global_costcode = "costcode"
  product = "product"
  environment = "environment"
  cloudwatch_rule_name = "Cloudwatch rule name"
  cloudwatch_rule_description = "Cloudwatch rue description"
  schedule_expression = "Cloudwatch expression"
  input_json = "Cloudwatch json"
  lambda_filename = "lambda filename"
  lambda_file_path = "lambda file path"
  lambda_function_name = "lambda function name"
  lambda_description = "lambda function description"
  lambda_role = "lambda role"
}
```

## Output:

| Output Name | Description         |
|-------------|---------------------|
| lambda_arn  | Lambda function ARN |
