## 2.0.0 (24 Sep 2017)
### Major Release
- Re-written code with conditional logic.

## 1.0.1 (3 July 2017)
### Improvements
- lambda tags will now get applied to lambda policy as well

## 1.0.0 (26 June 2017)
- Initial release
