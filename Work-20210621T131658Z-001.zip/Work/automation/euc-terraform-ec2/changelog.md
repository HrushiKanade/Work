## 3.0.0 (30 November 2018)
### Major Release
- Now supports EIP attachment

## 2.1.4 (30 November 2017)
### Improvements
- Default values for Schedule_start and schedule_stop variables

## 2.1.3 (31 October 2017)
### Fix
- Fixed issue with interpolation logic on ENI creation

## 2.1.2 (30 October 2017)
### Improvements
- Code change to support creation of root volume per instance.

## 2.1.1 (26 October 2017)
### Fix
- Fixed bug in private ip addressing and volume tags creation in ec2 module.

## 2.1.0 (24 October 2017)
### Minor Release
- Resolved bug in eni creation with private ip counts.

## 2.0.11 (27 September 2017)
### Improvement
- Modified EC2 Module to include additional optional variable "ebs_optimized".

## 2.0.10 (31 August 2017)
### Improvement
- Updated CPM Backup tag variable name
- Included CPM Tags to root volumes.

## 2.0.9 (23 August 2017)
### Improvement
- Updated interpolation condition on cpm backup tags to support multiple inputs

## 2.0.8 (21 August 2017)
### Improvement
- Updated EC2 Module to include interpolation for ami attribute.

## 2.0.7 (18 August 2017)
### Improvement
- Included CPM Backup tags in EC2 Module
- Included Tags for CPM Backup
### Fix
- Fixed issue with space in the CPM tag
- Fixed issue with conditional on CPM Backup tags

## 2.0.6 (02 August 2017)
### Improvement
- Included Additional tags.
### Fix
- Removed global_region attribute from ec2 module

## 2.0.5 (24 July 2017)
### Improvement
- Included Delete on Termination attribute for eni.

## 2.0.4 (21 July 2017)
### Improvement
- Included support to assign static IP during instance provisioning.

## 2.0.3 (05 July 2017)
### Improvement
- Included logic to support attachment of multiple SG to a single instance.
- Included logic to interpolate on tags for power schedule control.
- Added lifecycle rule to ignore changes to user_data

## 2.0.2 (22 June 2017)
### Improvement
- Modified script to support attachment of multiple SG to a single instance.

## 2.0.1 (20 June 2017)
### Fix
- changed split delimiter from "," to "@" for tags used by lambda.

## 2.0.0 (16 June 2017)
### Improvement
- Included Count Interpolation logic to provision multiple similar EC2 instances.
- Included logic to accept instance_profile on demand
- Included Create and destroy timeout which will help in waiting for provisioning to complete in case of delay.
- provisioning of multiple ip's can be done for both App and SQL type instances.
- conditionals included in Output.tf to provide outputs same attribute name regardless of type of instance we provision.

## 1.0.4 (9 June 2017)
### Improvement
- Included code to provision Instance with multiple private IP's.

## 1.0.3 (8 June 2017)
### Improvement
- Included code to configure IAM Instance Profile

## 1.0.2 (23 May 2017)
### Improvement
- Include tags creation for Root Volumes

## 1.0.1 (22 May 2017)
### Improvement
- Update Root volume default size to 50 GB.

## 1.0.0 (22 May 2017)
- Initial release
