# Elasticache Module:

## Git Project: git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-elasticache.git

## Description:

```
This Module is used to provision Elasticache cluster:
   •	Module supports creation of redis and memcache clusters.
   •	Creation of Subnet group to use with Cache Clusters.
```

## Input Variables:

| Variable Name                | Required | Description                                                                                         |
|------------------------------|----------|-----------------------------------------------------------------------------------------------------|
| vpc_contact                  | Yes      | Used in Tags. Provide the email address that managed this VPC                                       |
| global_costcode              | Yes      | Used in Tags, Provide the Costcode.                                                                 |
| global_orchestration         | Optional | Default is “terraform”.                                                                             |
| global_department            | Optional | Default is “tio”.                                                                                   |
| global_subdepartment         | Optional | Default is “euc”                                                                                    |
| global_country               | Optional | Default is “gb”                                                                                     |
| cloud_environment            | Optional | Default is “aws”                                                                                    |
| repo_url                     | Optional | Default is "git@gitlab.et-scm.com:tio-euc/euc-terraformcontrol-enterprise.git"                      |
| euc_tower                    | Optional | Default is “enterprise”                                                                             |
| environment                  | Yes      | Provide the Environment(Prod/Pre-Prod).                                                             |
| product                      | Yes      | Provide the “aws service name”.                                                                     |
| subnet_group_name            | Yes      | Name of the Subnet Group                                                                            |
| subnet_group_description     | Yes      | Description of the Subnet Group.                                                                    |
| subnet_id                    | Yes      | Subnet ID to add to the Subnet Group.                                                               |
| security_group_ids           | Yes      | Security Group ID’s to apply to the Elasticache.                                                    |
| cluster_id                   | Yes      | ID of the cluster.                                                                                  |
| engine                       | Optional | Defaults to memcache. Accepts input “memcache or redis”                                             |
| node_type                    | Optional | Default to cache.t2.micro.                                                                          |
| port                         | Optional | Default to port 11211                                                                               |
| num_cache_nodes              | Optional | Default to 2 nodes.                                                                                 |
| parameter_group_name         | Optional | Defaults to default.memcached1.4                                                                    |
| engine_version               | Optional | Defaults to 1.4.34                                                                                  |
| maintenance_window           | Optional | Defaults to “sun:05:00-sun:09:00”                                                                   |
| apply_immediately            | Optional | Defaults to true. Input should be false if the changes should not be applied immediately.           |
| az_mode                      | Optional | Defaults to single-az. Accept inputs “single-az or multi-az”                                        |
| availability_zone            | Optional | Provide the Availability Zone. To be used if single-az is used in az_mode.                          |
| availability_zones           | Optional | Provide the Availability Zones. To be used if multi-az is used in az_mode.                          |
| snapshot_window              | Optional | Defaults to 10:00-15:00                                                                             |
| override_num_cache_nodes     | Optional | Defaults to true. use only when overriding the number of nodes for memcache in single az            |
| default_parameter_group_name | NA       | Defaults to map type object of parameter_group_name.used only if parameter_group_name is not passed |
| default_engine_version       | NA       | Defaults to map type object of enginer version.used only if engine_version is not passed            |
| snapshot_retention_limit     | Optional | Defaults to 0. Only applicable if engine type is redis.                                             |
| snapshot_arns                | Optional | Defaults to "". Provide arn of snapshot.applicable only for redis.                                  |
| snapshot_name                | Optional | Defaults to "". Provide name of snapshot.applicable only for redis.                                 |

## Usage:

```
module "memcache" {
  source = "git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-elasticache.git"
  cluster_id = "cluster-id"
  security_group_ids = "security group ID"
  subnet_id = "subnet id"
  subnet_group_name = “subnet group name"
  subnet_group_description = "subnet group description"
  availability_zone = "availability zone"
  vpc_contact = "vpc contact"
  global_costcode = "cost code”
  product = "product"
  environment = "environment"
}
```

##Output:

| Output Name            | Description                 |
|------------------------|-----------------------------|
| cache_nodes            | Address of cache nodes      |
| configuration_endpoint | Elasticache endpoint.       |
| cluster_address        | Elasticache cluster address |
| subnet_group_name      | Subnet group name           |
