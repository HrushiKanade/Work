## 1.0.2 (11 December 2017)
### Improvements
- Added support to provision Redis cluster.
- Added support to support snapshot retention limits, snapshot arns and snapshot Name
- Added logic to check if the parameters supports creation of redis or memcached cluster. 

## 1.0.1 (9 August 2017)
### Improvements
- Tags added to cluster resource

## 1.0.0 (16 June 2017)
- Initial release
