#	Security Group Module:

## Git Project: git@gitlab.et-scm.com:tio-euc/euc-terraform-security_group.git

## Description:

```
This Module is used to create Security group and its associated rules.
  •	Blank Security Group
  •	Security Group Rules with SG ID
  •	Security Group Rules with CIDR
  •	Security Group Rules associated to Self.
```

## Input Variables:

| Variable Name       | Required | Description                                                                      |
|---------------------|----------|----------------------------------------------------------------------------------|
| vpc_id              | Yes      | VPC ID to associate the SG.                                                      |
| instance_name       | Yes      | Security Group Name                                                              |
| instance_count      | Yes      | Number of Security group to create                                               |
| sg_count            | Yes      | Number of Security group to create.                                              |
| security_group_id   | Yes      | SG ID to create the rules                                                        |
| description         | Optional | Description of the SG defaults to "This Security is Associated To instance_name" |
| rule_type_cidr_vars | Yes      | Should be “ingress” or “egress”                                                  |
| from_port_cidr_vars | Yes      | From ports                                                                       |
| to_port_cidr_vars   | Yes      | To ports                                                                         |
| protocol_cidr_vars  | Yes      | Should be “tcp or udp or icmp or all”                                            |
| cidr_blocks_vars    | Yes      | Accepts CIDR ranges for each ports as a map.                                     |
| rule_type_cidr_data | Yes      | Should be “ingress” or “egress”                                                  |
| from_port_cidr_data | Yes      | From ports                                                                       |
| to_port_cidr_data   | Yes      | To ports                                                                         |
| protocol_cidr_data  | Yes      | Should be “tcp or udp or icmp or all”                                            |
| cidr_blocks_data    | Yes      | CIDR values as string                                                            |
| rule_type_sgid      | Yes      | Should be “ingress” or “egress”                                                  |
| from_port_sgid      | Yes      | From ports                                                                       |
| to_port_sgid        | Yes      | To ports                                                                         |
| protocol_sgid       | Yes      | Should be “tcp or udp or icmp or all”                                            |
| sg_id               | Yes      | Security Group ID to reference the rules.                                        |
| rule_type_self      | Yes      | Should be “ingress” or “egress”                                                  |
| from_port_self      | Yes      | From ports                                                                       |
| to_port_self        | Yes      | To ports                                                                         |
| protocol_self       | Yes      | Should be “tcp or udp or icmp or all”                                            |
| self                | Yes      | Default is True                                                                  |
| vpc_contact         | Yes      | Used in Tags. Provide the email address that managed this VPC                    |
| global_costcode     | Yes      | Used in Tags, Provide the Costcode.                                              |
| product             | Yes      | Provide the “aws service name”.                                                  |
| environment         | Yes      | Provide the Environment(Prod/Pre-Prod).                                          |

## Usage:

### To create a New Security Group:

```
module "security_group" {
  source = "git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-security_group.git"
  vpc_id = “vpc_id"
  instance_name = “Security group name” <<Name of the security group>>
  description = "${var.security_group_description}"
  vpc_contact = "${var.vpc_contact}"
  global_costcode = "${var.global_costcode}"
  product = "product"
  environment = “Environment"
  instance_count = “1"<<number of security group to be created>>
  sg_count = “1"<<number of security group to be created>>
}
```

### To create Security Group rules with Self Reference:

```
module "security_group_rules" {
  source = "git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-security_group.git"
  rule_type_self = “ingress” or “egress”
  from_port_self = "80,443"<<comma separated string>>
  to_port_self = “81,445"<<comma separated string>>
  protocol_self = “tcp or udp or icmp or all”
 security_group_id = “Security Group ID”
}
```

### To create Security Group rules with CIDR:

```
module "security_group_rules" {
  source = "git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-security_group.git"
  rule_type_cidr_vars = “ingress” or “egress”
  from_port_cidr_vars = "80,443"<<comma separated string>>
  to_port_cidr_vars   = “81,445"<<comma separated string>>
  protocol_cidr_vars  = “tcp or udp or icmp or all”
  cidr_blocks_vars    = “{sg0 = “0.0.0.0/0 sg1 = “0.0.0.0/0”}” <<map type of variable”
  security_group_id   = "Security Group ID”
}
```

### To create Security Group rule referencing SG ID:

```
module "security_group_rules" {
  source = "git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-security_group.git"
  rule_type_sgid = “ingress” or “egress”
  from_port_sgid = "80,443"<<comma separated string>>
  to_port_sgid = “81,445"<<comma separated string>>
  protocol_sgid = “tcp or udp or icmp or all”
  sg_id = “Security Group ID”
  security_group_id = "Security Group ID”
}
```

## Output:

| Output Name       | Description       |
|-------------------|-------------------|
| security_group_id | Security group ID |
