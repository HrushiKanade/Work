## 1.0.3 (26 July 2017)
### Fix
- Uncommented code change for SG Name attribute

## 1.0.2 (21 July 2017)
### Fix
- Commented code change for SG Name attribute

## 1.0.2 (20 July 2017)
### Fix
- Updates Tags to match the Tags requirements document

## 1.0.1 (19 July 2017)
### Improvements
- Included SG Name attribute to Module.

## 1.0.0 (16 June 2017)
- Initial release
