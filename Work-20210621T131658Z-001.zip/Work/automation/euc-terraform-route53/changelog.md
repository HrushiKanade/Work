## 1.0.0 (11 November 2018)
- Initial release