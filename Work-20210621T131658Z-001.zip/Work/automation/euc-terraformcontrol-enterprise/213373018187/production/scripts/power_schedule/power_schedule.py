from __future__ import print_function
import sys
import json
import boto3
import logging
import datetime
import calendar
import pytz

def lambda_handler(event, context):
    get_instance_list(event,context)

def week_generator(x,y):
    i = []
    weekdays = []
    for j in y:
        if j in x:
            i.append(x.index(j))
    i = sorted(i)
    if len(i) > 1:
        for weekday in range(i[0],(i[1] +1 )):
            weekdays.append(x[weekday])
    elif len(i) == 1:
            weekdays.append(x[i[0]])
    else:
        print("not a valid week range")
    del i[:]
    return weekdays

def get_instance_list(event,context):
    currentdatetime = datetime.datetime.combine(datetime.date.today(), datetime.datetime.strptime(datetime.datetime.now().strftime("%H:%M"), '%H:%M').time())
    tz = pytz.timezone(event['tags'][2])
    currentdatetime=currentdatetime.astimezone(tz)
    currentdatetime = datetime.datetime.strptime(currentdatetime.strftime('%m/%d/%Y %H:%M:%S') , '%m/%d/%Y %H:%M:%S')
    instance_state = {'start':'stopped','stop':'running'}
    instance_collection = {}
    instance_split = []
    try:
        client = boto3.client('ec2',region_name = event['region'])
        client_lambda = boto3.client('lambda', region_name = event['region'])
    except Exception as err:
        print(err)
        logging_handler(event,err)
    response = client_lambda.list_tags(
        Resource=context.invoked_function_arn
    )
    if event['override_key'] in response['Tags'].keys():
        print(response['Tags'].keys())
        if response['Tags'][event['override_key']] != "all":
            instance_split = (response['Tags'][event['override_key']]).split(",")
        else:
            print(("Override %s set to all, hence skipping power schedule")%(str(event['override_key'])))
            return(("Override %s set to all, hence skipping power schedule")%(str(event['override_key'])))
            sys.exit(0)
    else:
        print("No Override Specified. Continuing With Normal Flow")
    for dict in event['tags'][0]:
        try:
            response = client.describe_instances(
                            DryRun=False,
                            Filters = [{
                                'Name': 'tag:%s'%(dict),
                                'Values': [event['tags'][0][dict]]
                                },
                                {
                                'Name': 'instance-state-name',
                                'Values': [instance_state[event['action']]]
                                }
                                ]
                        )
            if(len(response['Reservations']) > 0):
                for instances in response.get('Reservations'):
                    for tags in instances['Instances'][0]['Tags']:
                        if(tags['Key'] == 'Name'):
                            instance_name = tags['Value']
                        if(tags['Key'] == event['tags'][1]):
                            values = tags['Value'].split("|")
                            i = week_generator(list(calendar.day_abbr), [i.capitalize() for i in values[0].strip("()").split("-")])
                            actual_time = datetime.datetime.combine(datetime.date.today(), datetime.datetime.strptime(values[1],'%H:%M').time())
                            actual_time = actual_time.replace(tzinfo=pytz.timezone(event['tags'][2]))
                            actual_time = datetime.datetime.strptime(actual_time.strftime('%m/%d/%Y %H:%M:%S') , '%m/%d/%Y %H:%M:%S')
                            if(currentdatetime >= actual_time):
                                time_difference_in_minutes = (currentdatetime - actual_time) / datetime.timedelta(minutes=1)
                            else:
                                continue
                            if (((list(calendar.day_abbr)[datetime.datetime.today().weekday()].capitalize()) in i) and (time_difference_in_minutes <= 15)):
                                if values[1] in instance_collection:
                                    instance_collection[values[1]].append(instances['Instances'][0]['InstanceId']+":"+instance_name)
                                else:
                                    instance_collection[values[1]] = [instances['Instances'][0]['InstanceId']+":"+instance_name]
                            else:
                                print("No Valid Instances available for action")
            else:
               print("No Valid Instances available for action")
               return ("No Valid Instances available for action")
               sys.exit(0)
        except Exception as err:
            print(err)
            logging_handler(event,err)
    for times in sorted(instance_collection):
        instance_id = [instance_id.split(":")[0] for instance_id in instance_collection[times]]
        if(len(instance_split) > 0):
            instance_id = set.difference(set(instance_split),set(instance_id))
            instance_id = list(instance_id)
        if((len(instance_collection[times]) > 0) and (len(instance_id) > 0) and (event['action'] == "start")):
            instance_action(event,client,instance_id,instance_collection[times],event['action'])
        elif((len(instance_collection[times]) > 0) and (len(instance_id) > 0) and (event['action'] == "stop")):
            instance_action(event,client,instance_id,instance_collection[times],event['action'])
        else:
            return ("No Valid Instances available for action")
            sys.exit(0)

def instance_action(event,client,instance_id,instance_collections,action):
    try:
        if action == 'start':
            response = client.start_instances(
                DryRun=False,
                InstanceIds=instance_id
            )
            print(("Following instances %s were powered-on by lambda on %s")%(str(instance_collections),str(datetime.datetime.today().date())))
        elif action == 'stop':
            response = client.stop_instances(
                DryRun=False,
                InstanceIds=instance_id,
                Force=False
            )
            print(("Following instances %s were powered-off by lambda on %s")%(str(instance_collections),str(datetime.datetime.today().date())))
    except Exception as err:
        print(err)
        logging_handler(event,err)

def logging_handler(event, exception):
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.info('got event{}'.format(event))
    logger.error(exception)
    return exception
