# Lucanet deployment

## Usage
### Onboard new customer
1. Copy & Paste a `module "lncloud1010000X" {` block in [main.tf](./main.tf)
1. Adapt the variables according to the information provided by the client
1. Run `terraform plan && terraform apply`
1. Test the new environment (by also checking the CW dashboard)
1. Note the value in `initial_user_db_password` output variable, put it in the excel which was provided by the client and send the excel back to the client
