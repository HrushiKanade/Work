
import json, logging, boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)
client = boto3.client('cloudwatch')

def lambda_handler(event, context):
    response = client.describe_alarms(
        AlarmNamePrefix='LNFOS-Status-lncloudtest',
        MaxRecords=100
    )    
    logger.info("response describe_alarms: {}".format(response))
    for metricAlarm in response['MetricAlarms']:
      actionsEnabled = metricAlarm['ActionsEnabled']
      if actionsEnabled == True:
        logger.info("actionsEnabled == True for: {}".format(metricAlarm['AlarmName']))
        response = client.disable_alarm_actions(
          AlarmNames=[
            metricAlarm['AlarmName'],
          ]
        )
      elif actionsEnabled == False:
        logger.info("actionsEnabled == False for: {}".format(metricAlarm['AlarmName']))
        response = client.enable_alarm_actions(
          AlarmNames=[
            metricAlarm['AlarmName'],
          ]
        )
    