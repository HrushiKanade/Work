import json, logging, csv, boto3, time
from datetime import datetime
from datetime import timedelta
from decimal import Decimal
from boto3.dynamodb.conditions import Key, Attr
from time import mktime


logger = logging.getLogger()
logger.setLevel(logging.INFO)
client = boto3.client('cloudwatch')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('sla-report')
s3 = boto3.client('s3')

def report_metrics():
    startTime = datetime.utcnow() - timedelta(days=31)

    startTimeTimeStamp = Decimal(datetime.timestamp(startTime))
    items = []
    
    response = client.describe_alarms(
        AlarmNamePrefix='LNFOS-Status-',
    )  
    for metricAlarm in response['MetricAlarms']:
      lucanet_identifier = metricAlarm['AlarmName'].replace("LNFOS-Status-", "") 
     
      response = table.query(
        KeyConditionExpression=Key('timestamp').gt(startTimeTimeStamp) & Key('lucanet_identifier').eq(lucanet_identifier)
      )

      with open("/tmp/data.csv", "w") as file:
        csv_file = csv.writer(file, delimiter=";")
        csv_file.writerow(['lucanet_identifier','date', 'availability'])
        for item in response['Items']:
          csv_file.writerow([item['lucanet_identifier'],item['date'],item['availability']])
      logger.info("response for startTime: {}".format(startTime))
      logger.info(response['Items'])  
      csv_binary = open('/tmp/data.csv', 'rb').read()
      s3.put_object(ACL='private', Body=csv_binary, ContentType='text/csv', Bucket='lnfos-sla-reports', Key=lucanet_identifier+'-sla-report.csv')
      
def collect_metrics():
    startTime = datetime.utcnow() - timedelta(days=1)
    startTimeString = startTime.strftime("%d.%m.%Y")
    startTimeObj = datetime.strptime(startTimeString, "%d.%m.%Y")    
    #endTime = datetime.utcnow()
    endTime = datetime.utcnow() 
    endTimeString = endTime.strftime("%d.%m.%Y")
    endTimeObj = datetime.strptime(endTimeString, "%d.%m.%Y")
    
    maxDatapoints = 86400
    
    response = client.describe_alarms(
        AlarmNamePrefix='LNFOS-Status-',
    )  
    for metricAlarm in response['MetricAlarms']:
        imageId = ''
        instanceType = ''
        instanceId = ''
        for dimension in metricAlarm['Dimensions']:
            if dimension['Name'] == 'ImageId':
                imageId = dimension['Value']
            elif dimension['Name'] == 'InstanceType':
                instanceType = dimension['Value']
            elif dimension['Name'] == 'InstanceId':
                instanceId = dimension['Value']
            
        response = client.get_metric_data(
            MetricDataQueries=[
                {
                    'Id': 'string',
                    'MetricStat': {
                        'Metric': {
                            'Namespace': 'CWAgent',
                            'MetricName': 'collectd_curl_value',
                            'Dimensions': [
                                {
                                    'Name': 'type',
                                    'Value': 'response_code'
                                },
                                {
                                    'Name': 'instance',
                                    'Value': 'status'
                                }, 
                                {
                                    'Name': 'ImageId',
                                    'Value': imageId
                                },
                                {
                                    'Name': 'InstanceType',
                                    'Value': instanceType
                                },       
                                {
                                    'Name': 'InstanceId',
                                    'Value': instanceId
                                },                                 
                            ]
                        },
                        'Period': 60,
                        'Stat': 'Average'
                    },
                    'Label': 'SLA',
                    'ReturnData': True
                },
            ],
            StartTime=startTimeObj,
            EndTime=endTimeObj,
            ScanBy='TimestampDescending',
            MaxDatapoints=maxDatapoints
        );
        
        metricDataResults = response['MetricDataResults'][0]
        datapointsSuccessful = 0

        for metricDataResult in metricDataResults['Values']:
          http_code = int(metricDataResult)
          if (http_code >= 200 and http_code < 400):
            datapointsSuccessful += 1
            
        lucanet_identifier = metricAlarm['AlarmName'].replace("LNFOS-Status-", "")
        logger.info("metricDataResults!!! : {}".format(metricDataResults))
        logger.info("datapointsSuccessful!!! : {}".format(datapointsSuccessful))
        table.put_item(
          Item={
            'lucanet_identifier': lucanet_identifier,
            'date': startTimeString,
            'timestamp': Decimal(datetime.timestamp(startTimeObj)),
            'availability': str(datapointsSuccessful/1440*100).replace(".",","),
            }
        )
        logger.info("response for instanceId: {}".format(instanceId))
        logger.info(response)    

def lambda_handler(event, context):
    collect_metrics()
    report_metrics()