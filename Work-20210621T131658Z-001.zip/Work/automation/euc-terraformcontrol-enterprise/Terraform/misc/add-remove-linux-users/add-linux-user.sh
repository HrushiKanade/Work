USER_NAME=$1
SSH_KEY_CONTENT=$2

if [ "$#" -lt 2 ]; then
  echo "Usage: $0 username pub_key_content" >&2
  exit 1
fi
if [ "$(whoami)" != "root" ]; then
        echo "Script must be run as user: root"
        exit -1
fi
getent passwd $USER_NAME > /dev/null 2&>1

if [ $? -eq 0 ]; then
    echo "the user exists already"
    exit -1
fi

useradd -d /home/$USER_NAME -m -g lucanet $USER_NAME
usermod -aG lucanet $USER_NAME
mkdir /home/$USER_NAME/.ssh
touch /home/$USER_NAME/.ssh/authorized_keys
chown -R $USER_NAME:lucanet /home/$USER_NAME
chmod 700 /home/$USER_NAME/.ssh/
chmod 600 /home/$USER_NAME/.ssh/authorized_keys
echo -e "$USER_NAME" | passwd --stdin $USER_NAME
echo "$USER_NAME        ALL = NOPASSWD: /usr/sbin/service lucanet *" >> /etc/sudoers.d/lucanet-users
echo "$SSH_KEY_CONTENT" >> /home/$USER_NAME/.ssh/authorized_keys
