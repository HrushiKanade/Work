USER_NAME=$1

if [ "$#" -ne 1 ]; then
  echo "Usage: $0 username" >&2
  exit 1
fi
if [ "$(whoami)" != "root" ]; then
        echo "Script must be run as user: root"
        exit -1
fi
getent passwd $USER_NAME > /dev/null 2&>1
if [ $? -ne 0 ]; then
    echo "the user doesn't exists"
    exit -1
fi

sed -i "/^$USER_NAME/d" /etc/sudoers.d/lucanet-users
userdel -r $USER_NAME
