# VPC-Peering Module:

## Git Project: git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-vpc-peering.git

## Description:

```
This Module is used to configure vpc-peering:
  •	This Module can automatically accept the vpc peering connection from source account.
```

## Input Variables:

| Variable Name                | Required | Description                                                   |
|------------------------------|----------|---------------------------------------------------------------|
| vpc_contact                  | Yes      | Used in Tags. Provide the email address that managed this VPC |
| global_costcode              | Yes      | Used in Tags, Provide the Costcode.                           |
| global_orchestration         | Optional | Default is “terraform”.                                       |
| global_region                | Yes      | Provide the source region                                     |
| environment                  | Yes      | Provide the Environment(Prod/Pre-Prod).                       |
| product                      | Yes      | Provide the “aws service name”.                               |
| peer_provider                | Yes      | Provide the peer provider profile name. Acceptor Account      |
| vpc_id                       | Yes      | Requestor VPC ID                                              |
| peer_vpc_id                  | Yes      | Acceptor VPC ID                                               |
| accepter_route_table_id      | Yes      | Acceptor route table id                                       |
| peer_accepter_route_table_id | Yes      | Acceptor route table id                                       |
| requester_route_table_id     | Yes      | Requestor route table id                                      |

## Usage:

```
module "vpc_peering" {
  source = "git::ssh://git@gitlab.et-scm.com/tio-euc/euc-terraform-vpc-peering.git"
  peer_provider = "${var.peer_provider}"
  vpc_id   = "${module.vpc.vpc_id}"
  peer_vpc_id   = "${var.requester_vpc_id}"
  accepter_route_table_id = "${var.accepter_route_table_id}"
  requester_route_table_id = "${module.vpc.private_route_table}"
  vpc_contact = "${var.vpc_contact}"
  global_region = "${var.global_region}"
  global_costcode = "${var.global_costcode}"
  product = "${var.product}"
  environment = "${var.environment}"
}
```

##	Output:

| Output Name   | Description               |
|---------------|---------------------------|
| peering-id    | VPC peering ID            |
| accept_status | VPC Peering accept status |
